using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using XNode;
using UnityEditor;
using UnityEditor.UIElements;
using UnityEngine.UIElements; 
using XNodeEditor;
using System.Linq;

[CustomNodeEditor(typeof(DialogueNode))]
public class DialogueNodeDrawer : NodeEditor
{

    private DialogueNode dialogueNode;

    bool showingEntryNode = true;
    string entryNodeShowingLabel = "Hide Entry Node";

    bool nodeSettings = false;
    bool characterGroup = false;
    bool colorGroup = false;
    bool dialogueOptions = false;

    Color backgroundColor = Color.white;

    bool updateColor = false;
    bool startNode = false;

    bool updatedTitle = false;
    bool updatedDialogue = false;
    bool customName = false;
    string customNameStr = "Dialogue";

    [SerializeField]
    private SerializedProperty diaOptions;  

    [SerializeField]
    private List<string> options;

    int selectedPortToRemove = 0; 

    int tab;

    string newPort = "";
    enum PortType
    {
        input, output
    }
    PortType portType;

    Vector2 scroll;

    public override void OnBodyGUI()
    {
        if (dialogueNode == null)
        {
            dialogueNode = target as DialogueNode;
        }

        if (options == null)
        {
            options = new List<string>(); 
        }

        serializedObject.Update();

        UpdateOptions(); 

        if (dialogueNode.speaker.Length == 0)
        {
            EditorGUILayout.HelpBox("This dialogue has no speaker name. It will appear blank in play mode.", MessageType.Warning);
        }
        if (dialogueNode.dialogue.Length == 0)
        {
            EditorGUILayout.HelpBox("This dialogue has no speaker dialogue. It will appear blank in play mode.", MessageType.Error);
        }

        if (showingEntryNode)
        {
            NodeEditorGUILayout.PropertyField(serializedObject.FindProperty("entry"));
        }
        NodeEditorGUILayout.PropertyField(serializedObject.FindProperty("exit"));

        EditorGUILayout.BeginVertical();

        nodeSettings = EditorGUILayout.BeginFoldoutHeaderGroup(nodeSettings, "Node Settings");
        if (nodeSettings)
        {
            tab = GUILayout.Toolbar(tab, new string[] { "Add Port", "Remove Port" });
            switch (tab)
            {
                case 0:
                    float originalValue = EditorGUIUtility.labelWidth;
                    EditorGUIUtility.labelWidth = 150;
                    EditorGUILayout.PrefixLabel("New Port Name");
                    EditorGUIUtility.labelWidth = originalValue;
                    newPort = EditorGUILayout.TextField(newPort);
                    EditorGUILayout.PrefixLabel("Port Type");
                    portType = (PortType)EditorGUILayout.EnumPopup(portType);
                    EditorGUILayout.Space();
                    if (GUILayout.Button("Create New Port"))
                    {
                        if (newPort.Length == 0)
                        {
                            EditorUtility.DisplayDialog("Error creating port", "You need to give the port a name to create it.", "OK");
                            UpdateOptions(); 
                            return;
                        }
                        if (portType == PortType.input)
                        {
                            dialogueNode.AddDynamicInput(typeof(int), Node.ConnectionType.Multiple, Node.TypeConstraint.None, newPort);
                            dialogueNode.UpdatePorts();
                            UpdateOptions(); 
                            return;
                        }
                        NodePort newDynamPort = dialogueNode.AddDynamicOutput(typeof(int), Node.ConnectionType.Multiple, Node.TypeConstraint.None, newPort);
                        UpdateOptions(); 
                    }
                    EditorGUILayout.Space();
                    break;
                case 1:
                    if (options.Count == 0)
                    {
                        EditorGUILayout.HelpBox("You do not have any dynamic ports on this node.", MessageType.Warning);
                    }
                    else
                    {
                        EditorGUILayout.PrefixLabel("Choose Port");
                        selectedPortToRemove = EditorGUILayout.Popup(selectedPortToRemove, options.ToArray());
                        if (GUILayout.Button("Remove Port"))
                        {
                            dialogueNode.RemoveDynamicPort(dialogueNode.DynamicPorts.ElementAt(selectedPortToRemove));
                            selectedPortToRemove = 0; 
                            UpdateOptions(); 
                        }
                    }
                    break;
            }
        }

        EditorGUILayout.EndFoldoutHeaderGroup();

        characterGroup = EditorGUILayout.BeginFoldoutHeaderGroup(characterGroup, "Dialogue Settings");
        if (characterGroup)
        {
            float originalValue = EditorGUIUtility.labelWidth;
            EditorGUIUtility.labelWidth = 150;
            dialogueNode.character = (Sprite)EditorGUILayout.ObjectField("Character Sprite", dialogueNode.character, typeof(Sprite), true);
            EditorGUILayout.PrefixLabel("Speaker Name");

            EditorGUIUtility.labelWidth = originalValue;

            EditorGUI.BeginChangeCheck();
            dialogueNode.speaker = EditorGUILayout.TextField(dialogueNode.speaker);
            updatedTitle = EditorGUI.EndChangeCheck();

            GUIStyle style = new GUIStyle(EditorStyles.textArea);
            style.wordWrap = true;
            EditorGUILayout.PrefixLabel("Dialogue");

            EditorGUI.BeginChangeCheck();
            dialogueNode.dialogue = EditorGUILayout.TextArea(dialogueNode.dialogue, style);
            updatedDialogue = EditorGUI.EndChangeCheck();

            if (!customName && (updatedTitle || updatedDialogue))
            {
                UpdateTitle();
            }

            if (dialogueNode.DynamicOutputs.Count() > 0)
            {
                originalValue = EditorGUIUtility.labelWidth;
                EditorGUIUtility.labelWidth = 200;
                EditorGUILayout.PrefixLabel("Display dialogue options?");
                EditorGUIUtility.labelWidth = originalValue;
                dialogueNode.dialogueOptions = EditorGUILayout.Toggle(dialogueNode.dialogueOptions);
                if (dialogueNode.dialogueOptions)
                {
                    if (dialogueNode.DynamicOutputs.Count() > 3)
                    {
                        EditorGUILayout.HelpBox("The system does not support more than three dialogue options. The fourth option and thereafter will be ignored.", MessageType.Warning);
                    }

                    //dialogueNode.dialogueOptionList = new List<DialogueNode.DialogueOption>(); 

                    int index = 0; 
                    foreach (DialogueNode.DialogueOption d in dialogueNode.dialogueOptionList)
                    {
                        originalValue = EditorGUIUtility.labelWidth;
                        EditorGUIUtility.labelWidth = 200;
                        EditorGUILayout.LabelField(d.dialogue.Length > 0 ? (d.dialogue.Length > 13 ? d.dialogue.Substring(0, 13) + "..." : d.dialogue) : "Option " + (index + 1));

                        EditorGUIUtility.labelWidth = originalValue;

                        EditorGUILayout.PrefixLabel("Dialogue");
                        d.dialogue = EditorGUILayout.TextArea(d.dialogue, style);

                        EditorGUILayout.TextField("Exit Node", d.option);
                        EditorGUILayout.BeginHorizontal();
                        if (index != 0)
                        {
                            if (GUILayout.Button("Up"))
                            {
                                UpdateDialogueOptionPositions(index, -1);
                            }
                        }

                        if (index != dialogueNode.dialogueOptionList.Count - 1)
                        {
                            if (GUILayout.Button("Down"))
                            {
                                UpdateDialogueOptionPositions(index, 1);
                            }
                        }
                        EditorGUILayout.EndHorizontal(); 
                        index++; 
                    }

                    foreach (NodePort p in dialogueNode.DynamicOutputs)
                    {
                        NodeEditorGUILayout.PortField(p);
                    }
                }
            }
            else
            {
                EditorGUILayout.HelpBox("You do not have any dynamic outputs on this node. It will use the default exit.", MessageType.Info);
                dialogueNode.dialogueOptions = false; 
            }

        }
        EditorGUILayout.EndFoldoutHeaderGroup();

        colorGroup = EditorGUILayout.BeginFoldoutHeaderGroup(colorGroup, "Color Settings");
        if (colorGroup)
        {
            float originalValue = EditorGUIUtility.labelWidth;
            EditorGUIUtility.labelWidth = 200;
            dialogueNode.changeColor = EditorGUILayout.Toggle("Update Dialogue Box Color", dialogueNode.changeColor);
            if (dialogueNode.changeColor)
            {
                EditorGUILayout.PrefixLabel("New Box Color");
                dialogueNode.color = EditorGUILayout.ColorField(dialogueNode.color);
            }

            EditorGUIUtility.labelWidth = originalValue;
        }
        EditorGUILayout.EndFoldoutHeaderGroup();

        EditorGUILayout.EndVertical();

        serializedObject.ApplyModifiedProperties(); 

    }

    public void UpdateDialogueOptionPositions(int _index, int _adjust)
    {
        DialogueNode.DialogueOption tmp = dialogueNode.dialogueOptionList[_index];
        dialogueNode.dialogueOptionList[_index] = dialogueNode.dialogueOptionList[_index + _adjust];
        dialogueNode.dialogueOptionList[_index + _adjust] = tmp;
        serializedObject.Update();
    }

    public void UpdateOptions()
    {
        options.Clear(); 
        
        //Check if all nodeports accounted for
        foreach (NodePort p in dialogueNode.DynamicPorts)
        {
            options.Add(p.fieldName);
            bool found = false; 
            foreach (DialogueNode.DialogueOption d in dialogueNode.dialogueOptionList)
            {
                if (d.option == p.fieldName)
                {
                    found = true;
                    break; 
                }
            }
            if (!found)
            {
                dialogueNode.dialogueOptionList.Add(new DialogueNode.DialogueOption("", p.fieldName));
            }
        }

        //Check if all dialogueoptions accounted for
        foreach (DialogueNode.DialogueOption d in dialogueNode.dialogueOptionList)
        {
            bool found = false;
            foreach (NodePort p in dialogueNode.DynamicOutputs)
            {
                if (p.fieldName == d.option)
                {
                    found = true;
                    break; 
                }
            }
            if (!found)
            {
                dialogueNode.dialogueOptionList.Remove(d); 
            }
        }
    }

    public void UpdateTitle()
    {
        if (dialogueNode.speaker.Length + dialogueNode.dialogue.Length == 0)
        {
            this.Rename("Empty Dialogue Node");
        }
        else
        {
            string title = dialogueNode.speaker + ": " + dialogueNode.dialogue;
            this.Rename(title.Length < 28 ? title : title.Substring(0, 28) + "...");
        }
    }

    public override void AddContextMenuItems(GenericMenu menu)
    {
        base.AddContextMenuItems(menu);
        GUIContent content = new GUIContent("Set Start Node");
        menu.AddItem(content, startNode, UpdateStartNode);
    }

    public void UpdateStartNode()
    {
        DialogueGraph graph = dialogueNode.graph as DialogueGraph;
        graph.startNode = dialogueNode;
    }
}
