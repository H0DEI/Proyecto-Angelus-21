using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using XNode;
using XNodeEditor;

[CustomNodeEditor(typeof(StopNode))]
public class StopNodeDrawer : NodeEditor
{
    private StopNode stopNode;

    private bool startNode = false; 
    private bool StartNode
    {
        get
        {
            return startNode;
        }
        set
        {
            startNode = value;
            UpdateStartNode(); 
        }
    }

    public override void OnBodyGUI()
    {

        if (stopNode == null)
        {
            stopNode = target as StopNode; 
        }

        serializedObject.Update();

        NodeEditorGUILayout.PropertyField(serializedObject.FindProperty("entry"));

        GUIStyle stopIcon = new GUIStyle();
        stopIcon.alignment = TextAnchor.MiddleCenter;
        stopIcon.margin = new RectOffset(0, 0, 0, 0);
        stopIcon.padding = new RectOffset(0, 0, 0, 0);

        EditorGUILayout.HelpBox("This stops the current dialogue.", MessageType.Info);

        serializedObject.ApplyModifiedProperties(); 
    }

    public override void AddContextMenuItems(GenericMenu menu)
    {
        base.AddContextMenuItems(menu);
        GUIContent content = new GUIContent("Set Start Node");
        menu.AddItem(content, StartNode, UpdateStartNode);
    }

    public void UpdateStartNode()
    {
        DialogueGraph graph = stopNode.graph as DialogueGraph;
        graph.startNode = stopNode; 
    }
}

